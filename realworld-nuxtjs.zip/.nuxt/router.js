import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _6fcbbd64 = () => interopDefault(import('../pages/layout/index' /* webpackChunkName: "" */))
const _50ccdb31 = () => interopDefault(import('../pages/home/index.vue' /* webpackChunkName: "" */))
const _7da9bc15 = () => interopDefault(import('../pages/login/index' /* webpackChunkName: "" */))
const _1bd21fd6 = () => interopDefault(import('../pages/profile/index' /* webpackChunkName: "" */))
const _7229e446 = () => interopDefault(import('../pages/settings/index' /* webpackChunkName: "" */))
const _7f6c3532 = () => interopDefault(import('../pages/editor/index' /* webpackChunkName: "" */))
const _4422c5a2 = () => interopDefault(import('../pages/article/index' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _6fcbbd64,
    children: [{
      path: "",
      component: _50ccdb31,
      name: "home"
    }, {
      path: "/login",
      component: _7da9bc15,
      name: "login"
    }, {
      path: "/register",
      component: _7da9bc15,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _1bd21fd6,
      name: "profile"
    }, {
      path: "/settings",
      component: _7229e446,
      name: "settings"
    }, {
      path: "/editor",
      component: _7f6c3532,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _4422c5a2,
      name: "article"
    }]
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decodeURIComponent(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
